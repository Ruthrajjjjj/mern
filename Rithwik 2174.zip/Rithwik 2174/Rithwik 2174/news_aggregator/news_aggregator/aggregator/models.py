# aggregator/models.py

from django.db import models

class Source(models.Model):
    name = models.CharField(max_length=100)
    url = models.URLField()

    def __str__(self):
        return self.name

class Article(models.Model):
    title = models.CharField(max_length=200)
    url = models.URLField()
    source = models.ForeignKey(Source, on_delete=models.CASCADE)
    published_at = models.DateTimeField()

    def __str__(self):
        return self.title
