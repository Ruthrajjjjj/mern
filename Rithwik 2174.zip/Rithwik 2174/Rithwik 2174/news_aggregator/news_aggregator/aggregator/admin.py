# aggregator/admin.py

from django.contrib import admin
from .models import Source, Article

admin.site.register(Source)
admin.site.register(Article)
