# aggregator/views.py

from django.shortcuts import render
from .models import Article, Source

def home(request):
    sources = Source.objects.all()
    return render(request, 'aggregator/home.html', {'sources': sources})

def article_list(request, source_id):
    articles = Article.objects.filter(source_id=source_id)
    return render(request, 'aggregator/article_list.html', {'articles': articles})
