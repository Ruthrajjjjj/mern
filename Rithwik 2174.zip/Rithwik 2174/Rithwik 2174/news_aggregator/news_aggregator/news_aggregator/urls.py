from django.contrib import admin
from django.urls import path, include  # Import include here
from aggregator import views  # Import your views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('aggregator.urls')),  # Include app's URLs
]
